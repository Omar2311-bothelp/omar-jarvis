/* =========================================================
   memory.js — Local persistence layer
   Works standalone via localStorage. drive.js hooks into this
   to sync the same data shape to Google Drive when connected.
   ========================================================= */

const Memory = (() => {
  const KEYS = {
    LOG: 'omar.log.v1',
    NOTES: 'omar.notes.v1',
    REMINDERS: 'omar.reminders.v1',
    PREFS: 'omar.prefs.v1',
  };

  function _read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.warn('Memory read failed for', key, e);
      return fallback;
    }
  }

  function _write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn('Memory write failed for', key, e);
      return false;
    }
  }

  // ---- Conversation log ----
  function appendLog(entry) {
    const log = _read(KEYS.LOG, []);
    log.push({ ...entry, ts: Date.now() });
    // Keep last 500 entries locally so storage doesn't balloon
    const trimmed = log.slice(-500);
    _write(KEYS.LOG, trimmed);
    return trimmed;
  }

  function getLog() {
    return _read(KEYS.LOG, []);
  }

  function clearLog() {
    _write(KEYS.LOG, []);
  }

  // ---- Notes ----
  function addNote(text) {
    const notes = _read(KEYS.NOTES, []);
    const note = { id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), text, ts: Date.now() };
    notes.push(note);
    _write(KEYS.NOTES, notes);
    return note;
  }

  function getNotes() {
    return _read(KEYS.NOTES, []);
  }

  // ---- Reminders ----
  function addReminder(text, whenISO) {
    const reminders = _read(KEYS.REMINDERS, []);
    const reminder = {
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      text,
      when: whenISO || null,
      created: Date.now(),
      done: false,
    };
    reminders.push(reminder);
    _write(KEYS.REMINDERS, reminders);
    return reminder;
  }

  function getReminders() {
    return _read(KEYS.REMINDERS, []);
  }

  // ---- Prefs ----
  function getPrefs() {
    return _read(KEYS.PREFS, {
      voiceName: null,
      rate: 1,
      muted: false,
      wakeWordEnabled: false,
      driveClientId: null,
    });
  }

  function setPrefs(partial) {
    const current = getPrefs();
    const next = { ...current, ...partial };
    _write(KEYS.PREFS, next);
    return next;
  }

  // ---- Export / wipe ----
  function exportAll() {
    return {
      exportedAt: new Date().toISOString(),
      log: getLog(),
      notes: getNotes(),
      reminders: getReminders(),
    };
  }

  function wipeAll() {
    Object.values(KEYS).forEach((k) => {
      if (k !== KEYS.PREFS) localStorage.removeItem(k);
    });
  }

  return {
    KEYS,
    appendLog, getLog, clearLog,
    addNote, getNotes,
    addReminder, getReminders,
    getPrefs, setPrefs,
    exportAll, wipeAll,
  };
})();
