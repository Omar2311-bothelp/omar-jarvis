/* =========================================================
   voice.js — Speech recognition (STT) + synthesis (TTS)

   Cross-device reality check, baked in rather than ignored:
   - Samsung / Chrome (Android): SpeechRecognition works well,
     supports continuous mode reasonably, wake-word loop is viable.
   - iPad / Safari: webkitSpeechRecognition exists but:
       * requires a direct user gesture to start (no silent restart)
       * does NOT reliably support continuous:true in the background
       * will stop after a pause/silence and must be manually restarted
     So "always listening" on iPad is approximated by auto-restarting
     on the 'end' event WHILE the toggle is on AND the tab is foregrounded,
     not true background listening. We tell the user this in-app rather
     than pretending it's identical to Android.
   ========================================================= */

const Voice = (() => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const synth = window.speechSynthesis;

  const ua = navigator.userAgent || '';
  const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isAndroid = /Android/.test(ua);

  let recognizer = null;
  let listening = false;
  let wakeMode = false;
  let manuallyStoppedFlag = false;

  let onResult = () => {};
  let onStateChange = () => {};
  let onWakeWord = () => {};
  let onVolumeLevel = () => {};

  const support = {
    stt: !!SpeechRecognition,
    tts: !!synth,
    platform: isIOS ? 'ios' : isAndroid ? 'android' : 'desktop',
    // iOS Safari cannot reliably sustain continuous background recognition.
    reliableContinuous: !isIOS,
  };

  function init(handlers = {}) {
    onResult = handlers.onResult || onResult;
    onStateChange = handlers.onStateChange || onStateChange;
    onWakeWord = handlers.onWakeWord || onWakeWord;
    onVolumeLevel = handlers.onVolumeLevel || onVolumeLevel;

    if (!support.stt) return;

    recognizer = new SpeechRecognition();
    recognizer.lang = 'en-US';
    recognizer.interimResults = true;
    recognizer.continuous = support.reliableContinuous;
    recognizer.maxAlternatives = 1;

    recognizer.onresult = (event) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) final += transcript;
        else interim += transcript;
      }
      if (final) {
        const cleaned = final.trim();
        if (wakeMode && !listeningActive()) {
          // In wake mode but not in an "active command" window —
          // check for the wake word before treating as a command.
          if (/\bomar\b/i.test(cleaned)) {
            onWakeWord();
          }
        } else {
          onResult(cleaned, true);
        }
      } else if (interim) {
        onResult(interim, false);
      }
    };

    recognizer.onerror = (event) => {
      console.warn('Speech recognition error:', event.error);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        onStateChange('error', 'Microphone permission denied. Enable it in your browser/site settings.');
        wakeMode = false;
      } else if (event.error === 'no-speech') {
        // Common & harmless — just let onend handle restart logic.
      } else {
        onStateChange('error', `Speech error: ${event.error}`);
      }
    };

    recognizer.onend = () => {
      listening = false;
      onStateChange('idle');
      // Auto-restart only if wake mode is still desired AND we didn't
      // stop it manually AND we're in the foreground.
      if (wakeMode && !manuallyStoppedFlag && document.visibilityState === 'visible') {
        try {
          recognizer.start();
          listening = true;
          onStateChange('listening-ambient');
        } catch (e) {
          // start() can throw if called too soon after stop(); back off briefly.
          setTimeout(() => {
            if (wakeMode && !manuallyStoppedFlag) {
              try { recognizer.start(); listening = true; onStateChange('listening-ambient'); } catch (_) {}
            }
          }, 350);
        }
      }
    };
  }

  let activeCommandWindow = false;
  function listeningActive() { return activeCommandWindow; }

  function startOnce() {
    if (!support.stt || !recognizer) return false;
    manuallyStoppedFlag = false;
    activeCommandWindow = true;
    try {
      recognizer.start();
      listening = true;
      onStateChange('listening');
      return true;
    } catch (e) {
      console.warn('startOnce failed', e);
      return false;
    }
  }

  function stop() {
    manuallyStoppedFlag = true;
    activeCommandWindow = false;
    if (recognizer && listening) {
      try { recognizer.stop(); } catch (e) {}
    }
    listening = false;
  }

  function setWakeMode(enabled) {
    wakeMode = enabled;
    if (enabled) {
      manuallyStoppedFlag = false;
      activeCommandWindow = false;
      try {
        recognizer.start();
        listening = true;
        onStateChange('listening-ambient');
      } catch (e) {
        console.warn('wake mode start failed', e);
      }
    } else {
      stop();
    }
  }

  // ---- Text to speech ----
  let voices = [];
  function loadVoices() {
    voices = synth ? synth.getVoices() : [];
    return voices;
  }
  if (synth) {
    synth.onvoiceschanged = loadVoices;
    loadVoices();
  }

  function speak(text, opts = {}) {
    return new Promise((resolve) => {
      if (!support.tts || !text) { resolve(false); return; }
      const prefs = Memory.getPrefs();
      if (prefs.muted) { resolve(false); return; }

      // iOS Safari sometimes needs the queue cleared or it silently no-ops.
      synth.cancel();

      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = opts.rate ?? prefs.rate ?? 1;
      utter.pitch = 0.95;
      const chosenVoice = voices.find((v) => v.name === (opts.voiceName || prefs.voiceName));
      if (chosenVoice) utter.voice = chosenVoice;

      utter.onstart = () => onStateChange('speaking');
      utter.onend = () => { onStateChange('idle'); resolve(true); };
      utter.onerror = () => { onStateChange('idle'); resolve(false); };

      synth.speak(utter);
    });
  }

  function stopSpeaking() {
    if (synth) synth.cancel();
  }

  function getVoices() { return voices; }

  return {
    support,
    init, startOnce, stop, setWakeMode,
    speak, stopSpeaking, getVoices,
    endCommandWindow: () => { activeCommandWindow = false; },
  };
})();
