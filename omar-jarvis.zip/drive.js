/* =========================================================
   drive.js — Google Drive integration
   Uses Google Identity Services (GIS) token client for OAuth,
   then talks directly to the Drive v3 REST API via fetch.
   Stores OMAR's data as a single JSON file in appDataFolder
   (a hidden folder Drive reserves per-app — the user never
   sees clutter in their main Drive, and we don't need a
   picker or broad file scope).
   ========================================================= */

const Drive = (() => {
  const SCOPE = 'https://www.googleapis.com/auth/drive.appdata';
  const FILE_NAME = 'omar-jarvis-memory.json';

  let tokenClient = null;
  let accessToken = null;
  let fileId = null;
  let onStatusChange = () => {};

  function init(statusCallback) {
    if (typeof statusCallback === 'function') onStatusChange = statusCallback;
    const prefs = Memory.getPrefs();
    if (!prefs.driveClientId) {
      onStatusChange({ connected: false, reason: 'no-client-id' });
      return;
    }
    _initTokenClient(prefs.driveClientId);
  }

  function _initTokenClient(clientId) {
    if (!window.google || !window.google.accounts || !window.google.accounts.oauth2) {
      // GIS script may not have loaded yet (slow network / blocked) — retry shortly.
      setTimeout(() => _initTokenClient(clientId), 500);
      return;
    }
    tokenClient = google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: SCOPE,
      callback: (resp) => {
        if (resp && resp.access_token) {
          accessToken = resp.access_token;
          onStatusChange({ connected: true });
          _ensureFile();
        } else {
          onStatusChange({ connected: false, reason: 'auth-failed' });
        }
      },
      error_callback: (err) => {
        console.warn('Drive auth error', err);
        onStatusChange({ connected: false, reason: 'auth-error', detail: err });
      },
    });
  }

  function setClientId(clientId) {
    Memory.setPrefs({ driveClientId: clientId.trim() });
    _initTokenClient(clientId.trim());
  }

  function connect() {
    const prefs = Memory.getPrefs();
    if (!prefs.driveClientId) {
      onStatusChange({ connected: false, reason: 'no-client-id' });
      return;
    }
    if (!tokenClient) {
      _initTokenClient(prefs.driveClientId);
      setTimeout(() => tokenClient && tokenClient.requestAccessToken({ prompt: 'consent' }), 600);
      return;
    }
    tokenClient.requestAccessToken({ prompt: '' });
  }

  function disconnect() {
    accessToken = null;
    fileId = null;
    onStatusChange({ connected: false, reason: 'manual-disconnect' });
  }

  function isConnected() {
    return !!accessToken;
  }

  async function _authedFetch(url, options = {}) {
    if (!accessToken) throw new Error('not-authenticated');
    const headers = { ...(options.headers || {}), Authorization: `Bearer ${accessToken}` };
    const res = await fetch(url, { ...options, headers });
    if (res.status === 401) {
      accessToken = null;
      onStatusChange({ connected: false, reason: 'token-expired' });
      throw new Error('token-expired');
    }
    return res;
  }

  async function _ensureFile() {
    try {
      const q = encodeURIComponent(`name='${FILE_NAME}' and trashed=false`);
      const listRes = await _authedFetch(
        `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=${q}&fields=files(id,name)`
      );
      const listData = await listRes.json();
      if (listData.files && listData.files.length > 0) {
        fileId = listData.files[0].id;
        await pullFromDrive();
      } else {
        await _createFile();
      }
    } catch (e) {
      console.warn('Drive ensureFile failed', e);
    }
  }

  async function _createFile() {
    const metadata = { name: FILE_NAME, parents: ['appDataFolder'] };
    const initialContent = Memory.exportAll();
    const boundary = 'omar_boundary_' + Date.now();
    const body =
      `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n` +
      JSON.stringify(metadata) +
      `\r\n--${boundary}\r\nContent-Type: application/json\r\n\r\n` +
      JSON.stringify(initialContent) +
      `\r\n--${boundary}--`;

    const res = await _authedFetch(
      'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id',
      {
        method: 'POST',
        headers: { 'Content-Type': `multipart/related; boundary=${boundary}` },
        body,
      }
    );
    const data = await res.json();
    fileId = data.id;
  }

  async function pushToDrive() {
    if (!accessToken || !fileId) return false;
    try {
      const content = Memory.exportAll();
      await _authedFetch(`https://www.googleapis.com/upload/drive/v3/files/${fileId}?uploadType=media`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(content),
      });
      return true;
    } catch (e) {
      console.warn('Drive push failed', e);
      return false;
    }
  }

  async function pullFromDrive() {
    if (!accessToken || !fileId) return null;
    try {
      const res = await _authedFetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`);
      const data = await res.json();
      // Merge: Drive is treated as the source of truth on connect,
      // since it represents the longer-running memory across devices.
      if (data && Array.isArray(data.log)) {
        localStorage.setItem(Memory.KEYS.LOG, JSON.stringify(data.log));
      }
      if (data && Array.isArray(data.notes)) {
        localStorage.setItem(Memory.KEYS.NOTES, JSON.stringify(data.notes));
      }
      if (data && Array.isArray(data.reminders)) {
        localStorage.setItem(Memory.KEYS.REMINDERS, JSON.stringify(data.reminders));
      }
      onStatusChange({ connected: true, synced: true });
      return data;
    } catch (e) {
      console.warn('Drive pull failed', e);
      return null;
    }
  }

  // List files in the user's normal Drive (for future "read my files" skill).
  // Requires broader scope than appdata, so this is a stub Phase 2 can extend
  // by requesting drive.readonly scope explicitly when the user asks for it.
  async function listUserFiles(query) {
    throw new Error('listUserFiles requires drive.readonly scope — planned for Phase 2');
  }

  return {
    init, setClientId, connect, disconnect, isConnected,
    pushToDrive, pullFromDrive, listUserFiles,
  };
})();
