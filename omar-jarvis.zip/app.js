/* =========================================================
   app.js — Orchestration layer
   ========================================================= */

(() => {
  let els = {};
  let speakPulseInterval = null;

  document.addEventListener('DOMContentLoaded', () => {
    cacheEls();
    runBoot();
    wireUI();
    initSubsystems();
    startClock();
  });

  function cacheEls() {
    els = {
      bootScreen: document.getElementById('bootScreen'),
      app: document.getElementById('app'),
      bootLines: document.querySelectorAll('.boot-line'),

      clockText: document.getElementById('clockText'),
      driveDot: document.getElementById('driveDot'),
      driveText: document.getElementById('driveText'),
      settingsBtn: document.getElementById('settingsBtn'),

      stateValue: document.getElementById('stateValue'),
      sttValue: document.getElementById('sttValue'),
      ttsValue: document.getElementById('ttsValue'),
      platformValue: document.getElementById('platformValue'),
      memoryValue: document.getElementById('memoryValue'),
      quickCmds: document.getElementById('quickCmds'),

      reactorCanvas: document.getElementById('reactorCanvas'),
      reactorBtn: document.getElementById('reactorBtn'),
      reactorLabel: document.getElementById('reactorLabel'),
      reactorCaption: document.getElementById('reactorCaption'),
      wakeToggle: document.getElementById('wakeToggle'),

      transcript: document.getElementById('transcript'),
      inputForm: document.getElementById('inputForm'),
      textInput: document.getElementById('textInput'),
      dockRight: document.getElementById('dockRight'),
      mobileFab: document.getElementById('mobileTranscriptFab'),

      settingsOverlay: document.getElementById('settingsOverlay'),
      closeSettings: document.getElementById('closeSettings'),
      clientIdInput: document.getElementById('clientIdInput'),
      saveClientIdBtn: document.getElementById('saveClientIdBtn'),
      connectDriveBtn: document.getElementById('connectDriveBtn'),
      disconnectDriveBtn: document.getElementById('disconnectDriveBtn'),
      driveStatusHint: document.getElementById('driveStatusHint'),
      setupGuideBtn: document.getElementById('setupGuideBtn'),
      guideOverlay: document.getElementById('guideOverlay'),
      closeGuide: document.getElementById('closeGuide'),

      voiceSelect: document.getElementById('voiceSelect'),
      rateSlider: document.getElementById('rateSlider'),
      muteToggle: document.getElementById('muteToggle'),
      exportLogBtn: document.getElementById('exportLogBtn'),
      wipeMemoryBtn: document.getElementById('wipeMemoryBtn'),
    };
  }

  // ---------------- Boot sequence ----------------
  function runBoot() {
    const lines = Array.from(els.bootLines);
    let i = 0;
    function step() {
      if (i > 0) lines[i - 1].classList.replace('boot-active', 'boot-done');
      if (i < lines.length) {
        lines[i].classList.add('boot-active');
        i++;
        setTimeout(step, 420);
      } else {
        setTimeout(finishBoot, 380);
      }
    }
    step();
  }

  function finishBoot() {
    els.bootScreen.classList.add('boot-hide');
    els.app.classList.add('app-visible');
    els.app.setAttribute('aria-hidden', 'false');
    setTimeout(() => { els.bootScreen.style.display = 'none'; }, 650);
  }

  // ---------------- Subsystem init ----------------
  function initSubsystems() {
    Reactor.init(els.reactorCanvas);

    // Platform readout
    els.platformValue.textContent = Voice.support.platform === 'ios' ? 'iPAD / iOS'
      : Voice.support.platform === 'android' ? 'ANDROID' : 'DESKTOP';

    if (!Voice.support.stt) {
      els.sttValue.textContent = 'UNSUPPORTED';
      els.sttValue.classList.add('tv-warn');
      toast('Speech recognition isn\'t supported in this browser. Use the text input below instead.', 'warn');
    } else {
      els.sttValue.textContent = 'READY';
    }

    if (!Voice.support.tts) {
      els.ttsValue.textContent = 'UNSUPPORTED';
      els.ttsValue.classList.add('tv-warn');
    } else {
      els.ttsValue.textContent = 'READY';
    }

    if (Voice.support.platform === 'ios') {
      addMessage('system', 'Heads up: iPad Safari can\'t sustain background listening the way Android Chrome can — wake mode here restarts on each pause rather than running continuously. Tap-to-speak is the most reliable mode on this device.');
    }

    Voice.init({
      onResult: handleSpeechResult,
      onStateChange: handleVoiceState,
      onWakeWord: handleWakeWord,
    });

    Drive.init(handleDriveStatus);
    const prefs = Memory.getPrefs();
    if (prefs.driveClientId) els.clientIdInput.value = prefs.driveClientId;
    els.muteToggle.checked = !!prefs.muted;
    els.rateSlider.value = prefs.rate ?? 1;
    populateVoiceList();
    setTimeout(populateVoiceList, 400); // voices list loads async on some browsers
  }

  function populateVoiceList() {
    const voices = Voice.getVoices();
    if (!voices.length) return;
    const prefs = Memory.getPrefs();
    els.voiceSelect.innerHTML = '';
    voices.filter((v) => v.lang.startsWith('en')).forEach((v) => {
      const opt = document.createElement('option');
      opt.value = v.name;
      opt.textContent = `${v.name} (${v.lang})`;
      if (v.name === prefs.voiceName) opt.selected = true;
      els.voiceSelect.appendChild(opt);
    });
  }

  // ---------------- Clock ----------------
  function startClock() {
    function tick() {
      els.clockText.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
    tick();
    setInterval(tick, 1000);
  }

  // ---------------- UI wiring ----------------
  function wireUI() {
    els.reactorBtn.addEventListener('click', onReactorTap);

    els.wakeToggle.addEventListener('change', async (e) => {
      if (e.target.checked) {
        if (!Voice.support.stt) {
          toast('Speech recognition unsupported on this browser.', 'warn');
          e.target.checked = false;
          return;
        }
        const micOk = await Reactor.attachMic();
        if (!micOk) {
          toast('Microphone access denied or unavailable.', 'warn');
          e.target.checked = false;
          return;
        }
        Voice.setWakeMode(true);
        toast(Voice.support.platform === 'ios'
          ? 'Ambient listening on (best-effort on iOS — restarts on pauses).'
          : 'Ambient listening on. Say "Omar" to wake me.', 'good');
      } else {
        Voice.setWakeMode(false);
        Reactor.detachMic();
        Reactor.setState('idle');
        els.stateValue.textContent = 'STANDBY';
      }
    });

    els.inputForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = els.textInput.value.trim();
      if (!val) return;
      els.textInput.value = '';
      handleUserUtterance(val);
    });

    els.quickCmds.addEventListener('click', (e) => {
      const btn = e.target.closest('.cmd-pill');
      if (!btn) return;
      handleUserUtterance(btn.dataset.cmd);
    });

    els.mobileFab.addEventListener('click', () => {
      els.dockRight.classList.toggle('dock-open');
    });

    // Settings overlay
    els.settingsBtn.addEventListener('click', () => openOverlay(els.settingsOverlay));
    els.closeSettings.addEventListener('click', () => closeOverlay(els.settingsOverlay));
    els.settingsOverlay.addEventListener('click', (e) => { if (e.target === els.settingsOverlay) closeOverlay(els.settingsOverlay); });

    els.setupGuideBtn.addEventListener('click', () => openOverlay(els.guideOverlay));
    els.closeGuide.addEventListener('click', () => closeOverlay(els.guideOverlay));
    els.guideOverlay.addEventListener('click', (e) => { if (e.target === els.guideOverlay) closeOverlay(els.guideOverlay); });

    els.saveClientIdBtn.addEventListener('click', () => {
      const id = els.clientIdInput.value.trim();
      if (!id) { toast('Enter a Client ID first.', 'warn'); return; }
      Drive.setClientId(id);
      toast('Client ID saved.', 'good');
    });

    els.connectDriveBtn.addEventListener('click', () => Drive.connect());
    els.disconnectDriveBtn.addEventListener('click', () => {
      Drive.disconnect();
      toast('Drive disconnected.', 'warn');
    });

    els.voiceSelect.addEventListener('change', () => {
      Memory.setPrefs({ voiceName: els.voiceSelect.value });
    });
    els.rateSlider.addEventListener('input', () => {
      Memory.setPrefs({ rate: parseFloat(els.rateSlider.value) });
    });
    els.muteToggle.addEventListener('change', () => {
      Memory.setPrefs({ muted: els.muteToggle.checked });
    });

    els.exportLogBtn.addEventListener('click', () => {
      const data = Memory.exportAll();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `omar-export-${Date.now()}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    });

    els.wipeMemoryBtn.addEventListener('click', () => {
      if (confirm('This clears all local notes, reminders, and transcript history. Continue?')) {
        Memory.wipeAll();
        els.transcript.innerHTML = '';
        addMessage('system', 'Local memory wiped. Starting fresh.');
        toast('Local memory wiped.', 'good');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeOverlay(els.settingsOverlay);
        closeOverlay(els.guideOverlay);
      }
    });
  }

  function openOverlay(el) { el.classList.add('overlay-open'); el.setAttribute('aria-hidden', 'false'); }
  function closeOverlay(el) { el.classList.remove('overlay-open'); el.setAttribute('aria-hidden', 'true'); }

  // ---------------- Reactor tap-to-talk ----------------
  function onReactorTap() {
    if (!Voice.support.stt) {
      toast('Voice input unsupported here — type your command instead.', 'warn');
      els.textInput.focus();
      return;
    }
    const started = Voice.startOnce();
    if (started) {
      Reactor.attachMic();
      Reactor.setState('listening');
      els.reactorBtn.classList.add('state-listening');
      els.reactorLabel.innerHTML = 'LISTENING';
      els.reactorCaption.textContent = 'Listening…';
      els.stateValue.textContent = 'LISTENING';
      els.stateValue.classList.add('tv-active');
    }
  }

  function handleVoiceState(state, detail) {
    if (state === 'idle') {
      els.reactorBtn.classList.remove('state-listening', 'state-speaking');
      els.reactorLabel.innerHTML = 'TAP TO<br/>SPEAK';
      els.reactorCaption.textContent = 'Awaiting input';
      els.stateValue.textContent = 'STANDBY';
      els.stateValue.classList.remove('tv-active');
      Reactor.setState('idle');
    } else if (state === 'listening' || state === 'listening-ambient') {
      Reactor.setState('listening');
      els.reactorCaption.textContent = state === 'listening-ambient' ? 'Ambient listening…' : 'Listening…';
    } else if (state === 'speaking') {
      Reactor.setState('speaking');
      els.reactorBtn.classList.add('state-speaking');
      els.reactorCaption.textContent = 'Speaking…';
      els.stateValue.textContent = 'SPEAKING';
      els.stateValue.classList.add('tv-active');
      if (speakPulseInterval) clearInterval(speakPulseInterval);
      speakPulseInterval = setInterval(() => Reactor.pulseForSpeaking(), 120);
    } else if (state === 'error') {
      toast(detail || 'Voice error.', 'warn');
      els.reactorBtn.classList.remove('state-listening');
      Reactor.setState('idle');
    }
    if (state !== 'speaking' && speakPulseInterval) {
      clearInterval(speakPulseInterval);
      speakPulseInterval = null;
    }
  }

  function handleSpeechResult(text, isFinal) {
    if (!isFinal) {
      els.reactorCaption.textContent = `"${text}"`;
      return;
    }
    Voice.endCommandWindow();
    els.reactorBtn.classList.remove('state-listening');
    handleUserUtterance(text);
  }

  function handleWakeWord() {
    els.reactorCaption.textContent = 'Yes?';
    toast('Wake word detected.', 'good');
    Voice.startOnce();
  }

  // ---------------- Core conversation handling ----------------
  function handleUserUtterance(text) {
    addMessage('user', text);
    Memory.appendLog({ role: 'user', text });

    els.stateValue.textContent = 'THINKING';
    Reactor.setState('thinking');

    setTimeout(() => {
      const result = Brain.process(text);
      addMessage('system', result.reply);
      Memory.appendLog({ role: 'omar', text: result.reply, intent: result.intent });

      applyAction(result.action);
      Voice.speak(result.reply);

      if (result.sync && Drive.isConnected()) {
        Drive.pushToDrive();
      }
    }, 260);
  }

  function applyAction(action) {
    switch (action) {
      case 'open-settings':
        openOverlay(els.settingsOverlay);
        break;
      case 'clear-transcript':
        els.transcript.innerHTML = '';
        break;
      case 'mute':
        Memory.setPrefs({ muted: true });
        els.muteToggle.checked = true;
        break;
      case 'unmute':
        Memory.setPrefs({ muted: false });
        els.muteToggle.checked = false;
        break;
      default: break;
    }
  }

  function addMessage(role, text) {
    const wrap = document.createElement('div');
    wrap.className = `msg msg-${role === 'user' ? 'user' : 'system'}`;
    const tag = document.createElement('span');
    tag.className = 'msg-tag';
    tag.textContent = role === 'user' ? 'YOU' : 'OMAR';
    const p = document.createElement('p');
    p.textContent = text;
    wrap.appendChild(tag);
    wrap.appendChild(p);
    els.transcript.appendChild(wrap);
    els.transcript.scrollTop = els.transcript.scrollHeight;
  }

  // ---------------- Drive status ----------------
  function handleDriveStatus(status) {
    if (status.connected) {
      els.driveDot.classList.remove('dot-off');
      els.driveDot.classList.add('dot-on');
      els.driveText.textContent = 'DRIVE SYNCED';
      els.memoryValue.textContent = 'DRIVE + LOCAL';
      els.driveStatusHint.textContent = 'Connected. Your notes, reminders, and transcript sync to a private app-data file in your Drive.';
      if (status.synced) toast('Memory synced from Drive.', 'good');
    } else {
      els.driveDot.classList.remove('dot-on');
      els.driveDot.classList.add('dot-off');
      els.driveText.textContent = 'DRIVE OFFLINE';
      els.memoryValue.textContent = 'LOCAL ONLY';
      if (status.reason === 'no-client-id') {
        els.driveStatusHint.textContent = 'Not connected. Add an OAuth Client ID below to enable Drive sync.';
      } else if (status.reason === 'auth-failed' || status.reason === 'auth-error') {
        els.driveStatusHint.textContent = 'Connection failed. Double check your Client ID and authorized origin, then try again.';
        toast('Drive connection failed.', 'warn');
      } else if (status.reason === 'token-expired') {
        els.driveStatusHint.textContent = 'Session expired — tap Connect Drive to reconnect.';
      }
    }
  }

  // ---------------- Toasts ----------------
  let toastStack = null;
  function toast(msg, kind = '') {
    if (!toastStack) {
      toastStack = document.createElement('div');
      toastStack.className = 'toast-stack';
      document.body.appendChild(toastStack);
    }
    const el = document.createElement('div');
    el.className = `toast ${kind ? 'toast-' + kind : ''}`;
    el.textContent = msg;
    toastStack.appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }
})();
