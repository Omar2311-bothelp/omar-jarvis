/* =========================================================
   brain.js — Rule-based response engine (Phase 1)

   Structured around an intent-matcher array so Phase 2 can
   swap this whole module for an API-backed brain without
   touching app.js: process(input) is the only contract that
   matters — it always returns { reply, action? }.
   ========================================================= */

const Brain = (() => {
  const intents = [
    {
      name: 'greeting',
      test: (t) => /^(hey|hi|hello|sup|yo)\b/i.test(t) || /\bomar\b/i.test(t) && t.length < 14,
      run: () => pick([
        "I'm here. What do you need?",
        "Online and listening.",
        "Go ahead.",
      ]),
    },
    {
      name: 'time',
      test: (t) => /what('?s| is) the time|current time|what time is it/i.test(t),
      run: () => `It's ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
    },
    {
      name: 'date',
      test: (t) => /what('?s| is) the date|today'?s date|what day is it/i.test(t),
      run: () => `Today is ${new Date().toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}.`,
    },
    {
      name: 'note',
      test: (t) => /^(take a note|note that|remember that|jot down)\b/i.test(t),
      run: (t) => {
        const text = t.replace(/^(take a note|note that|remember that|jot down)\b[:,]?\s*/i, '').trim();
        if (!text) return { reply: "What should I note down?", action: 'await-note' };
        const note = Memory.addNote(text);
        return { reply: `Noted: "${truncate(note.text, 60)}".`, action: 'note-saved', sync: true };
      },
    },
    {
      name: 'reminder',
      test: (t) => /^(set a reminder|remind me)\b/i.test(t),
      run: (t) => {
        const text = t.replace(/^(set a reminder to|set a reminder|remind me to|remind me)\b[:,]?\s*/i, '').trim();
        if (!text) return { reply: "What should I remind you about?", action: 'await-reminder' };
        const r = Memory.addReminder(text);
        return { reply: `Reminder logged: "${truncate(r.text, 60)}". Note: I can't trigger native phone notifications yet — that lands in a later phase. Check the transcript or your notes for it.`, action: 'reminder-saved', sync: true };
      },
    },
    {
      name: 'list-notes',
      test: (t) => /show (me )?(my )?notes|what are my notes|read (me )?(my )?notes/i.test(t),
      run: () => {
        const notes = Memory.getNotes();
        if (!notes.length) return "You don't have any notes yet.";
        const last = notes.slice(-5).reverse();
        return `Your last ${last.length} note${last.length > 1 ? 's' : ''}: ` + last.map((n) => `"${truncate(n.text, 40)}"`).join('; ') + '.';
      },
    },
    {
      name: 'list-reminders',
      test: (t) => /show (me )?(my )?reminders|what are my reminders/i.test(t),
      run: () => {
        const reminders = Memory.getReminders().filter((r) => !r.done);
        if (!reminders.length) return "No active reminders.";
        return `You have ${reminders.length} reminder${reminders.length > 1 ? 's' : ''}: ` + reminders.map((r) => `"${truncate(r.text, 40)}"`).join('; ') + '.';
      },
    },
    {
      name: 'open-drive',
      test: (t) => /open drive|connect drive|google drive/i.test(t),
      run: () => ({ reply: "Opening Drive settings.", action: 'open-settings' }),
    },
    {
      name: 'clear-screen',
      test: (t) => /^clear( screen)?$|^clear the (screen|transcript)$/i.test(t),
      run: () => ({ reply: "Clearing transcript.", action: 'clear-transcript' }),
    },
    {
      name: 'mute',
      test: (t) => /^(mute|stop talking|be quiet|silence)\b/i.test(t),
      run: () => ({ reply: "Going quiet.", action: 'mute' }),
    },
    {
      name: 'unmute',
      test: (t) => /^(unmute|speak up|you can talk)\b/i.test(t),
      run: () => ({ reply: "Voice output restored.", action: 'unmute' }),
    },
    {
      name: 'identity',
      test: (t) => /who are you|what are you|your name/i.test(t),
      run: () => "I'm Omar — your personal intelligence shell. Phase 1: voice, memory, and a foundation for everything that comes next.",
    },
    {
      name: 'capabilities',
      test: (t) => /what can you do|help\b/i.test(t),
      run: () => "Right now: tell time and date, take notes, log reminders, manage Drive sync, and chat in a limited rule-based way. Ask me to 'show my notes' or 'open drive' to see it in action. Real reasoning arrives in Phase 2.",
    },
    {
      name: 'thanks',
      test: (t) => /^(thanks|thank you|thx|appreciate it)\b/i.test(t),
      run: () => pick(["Anytime.", "That's what I'm here for.", "Always."]),
    },
  ];

  function process(rawInput) {
    const t = rawInput.trim();
    if (!t) return { reply: "I didn't catch that." };

    for (const intent of intents) {
      if (intent.test(t)) {
        const result = intent.run(t);
        if (typeof result === 'string') return { reply: result, intent: intent.name };
        return { ...result, intent: intent.name };
      }
    }

    return {
      reply: "I don't have a rule for that yet — Phase 1 only covers basic commands. That's exactly the gap Phase 2's reasoning engine will close.",
      intent: 'fallback',
    };
  }

  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function truncate(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

  return { process };
})();
