/* =========================================================
   reactor.js — Canvas HUD visualizer for the center reactor

   States: idle (slow ambient pulse), listening (reacts to mic
   amplitude via AnalyserNode), speaking (reacts to a synthetic
   pulse since we can't tap TTS audio directly), thinking
   (steady rotating scan sweep).
   ========================================================= */

const Reactor = (() => {
  let canvas, ctx, dpr;
  let raf = null;
  let state = 'idle';
  let t = 0;

  let analyser = null;
  let micData = null;
  let audioCtx = null;
  let micStream = null;

  let syntheticLevel = 0; // used to fake amplitude during TTS playback

  function init(canvasEl) {
    canvas = canvasEl;
    ctx = canvas.getContext('2d');
    resize();
    window.addEventListener('resize', resize);
    loop();
  }

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
  }

  function setState(next) {
    state = next;
  }

  async function attachMic() {
    try {
      if (audioCtx) return true;
      micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(micStream);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      micData = new Uint8Array(analyser.frequencyBinCount);
      source.connect(analyser);
      return true;
    } catch (e) {
      console.warn('Reactor mic attach failed (visual-only fallback active):', e);
      return false;
    }
  }

  function detachMic() {
    if (micStream) {
      micStream.getTracks().forEach((tr) => tr.stop());
      micStream = null;
    }
    if (audioCtx) {
      audioCtx.close().catch(() => {});
      audioCtx = null;
    }
    analyser = null;
  }

  function pulseForSpeaking() {
    // Called periodically by app.js while TTS is active, since we don't
    // have a direct tap into SpeechSynthesis audio output.
    syntheticLevel = 0.35 + Math.random() * 0.5;
  }

  function getAmplitude() {
    if (state === 'listening' && analyser && micData) {
      analyser.getByteFrequencyData(micData);
      let sum = 0;
      for (let i = 0; i < micData.length; i++) sum += micData[i];
      const avg = sum / micData.length / 255;
      return Math.min(1, avg * 2.2);
    }
    if (state === 'speaking') {
      syntheticLevel *= 0.9;
      return syntheticLevel;
    }
    return 0;
  }

  function loop() {
    raf = requestAnimationFrame(loop);
    t += 1;
    draw();
  }

  function draw() {
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    const cx = w / 2, cy = h / 2;
    const baseR = Math.min(w, h) * 0.42;

    const amp = getAmplitude();
    const colors = {
      idle: '#C9974A',
      listening: '#5FE8E0',
      speaking: '#5FE8E0',
      thinking: '#E8973F',
    };
    const color = colors[state] || colors.idle;

    // Outer scan ring — rotates always, faster when thinking
    const rotSpeed = state === 'thinking' ? 0.04 : 0.008;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(t * rotSpeed);
    ctx.strokeStyle = hexA(color, 0.5);
    ctx.lineWidth = 1.5 * dpr;
    ctx.beginPath();
    ctx.arc(0, 0, baseR * 1.18, 0, Math.PI * 1.3);
    ctx.stroke();
    ctx.restore();

    // Tick marks ring
    ctx.save();
    ctx.translate(cx, cy);
    const ticks = 48;
    for (let i = 0; i < ticks; i++) {
      const angle = (i / ticks) * Math.PI * 2;
      const active = (i + Math.floor(t / 4)) % ticks < (state === 'idle' ? 0 : 6);
      ctx.rotate(angle - (i === 0 ? 0 : (Math.PI * 2) / ticks));
      ctx.beginPath();
      const inner = baseR * 1.0;
      const outer = baseR * (active ? 1.09 : 1.05);
      ctx.moveTo(inner, 0);
      ctx.lineTo(outer, 0);
      ctx.strokeStyle = hexA(color, active ? 0.85 : 0.18);
      ctx.lineWidth = 1.2 * dpr;
      ctx.stroke();
      ctx.rotate(-(angle - (i === 0 ? 0 : (Math.PI * 2) / ticks)));
    }
    ctx.restore();

    // Pulse rings reacting to amplitude (listening/speaking) or ambient breathing (idle)
    const breathing = state === 'idle' ? (Math.sin(t * 0.03) + 1) / 2 : 0;
    const reactiveR = baseR * (0.62 + amp * 0.28 + breathing * 0.04);

    for (let ring = 0; ring < 3; ring++) {
      const ringR = reactiveR + ring * (6 + amp * 10) * dpr;
      ctx.beginPath();
      ctx.arc(cx, cy, ringR, 0, Math.PI * 2);
      ctx.strokeStyle = hexA(color, 0.32 - ring * 0.09);
      ctx.lineWidth = (2 - ring * 0.4) * dpr;
      ctx.stroke();
    }

    // Inner glow disc behind the button (button itself is HTML/CSS on top)
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, baseR * 0.5);
    grad.addColorStop(0, hexA(color, 0.16 + amp * 0.25));
    grad.addColorStop(1, hexA(color, 0));
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, baseR * 0.5, 0, Math.PI * 2);
    ctx.fill();

    // Data readout arcs (cosmetic, HUD detail) — only visible when not idle
    if (state !== 'idle') {
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(-t * rotSpeed * 1.6);
      ctx.strokeStyle = hexA(color, 0.4);
      ctx.lineWidth = 1 * dpr;
      ctx.beginPath();
      ctx.arc(0, 0, baseR * 1.3, 0.2, 0.9);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, baseR * 1.3, Math.PI + 0.2, Math.PI + 0.9);
      ctx.stroke();
      ctx.restore();
    }
  }

  function hexA(hex, alpha) {
    const h = hex.replace('#', '');
    const r = parseInt(h.substring(0, 2), 16);
    const g = parseInt(h.substring(2, 4), 16);
    const b = parseInt(h.substring(4, 6), 16);
    return `rgba(${r},${g},${b},${alpha})`;
  }

  return { init, setState, attachMic, detachMic, pulseForSpeaking };
})();
